# GoatHub
### The website we deserve, even if it's not the one we need.

GoatHub is the best goat voting service in the world.

Hackathon project built at [Codestellation 2015](http://codestellation.io/)


